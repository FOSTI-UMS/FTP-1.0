window.$ = window.jQuery = require('jquery');
require('bootstrap');
require('bootstrap/dist/css/bootstrap.css');
require('daterangepicker');
require('daterangepicker/daterangepicker.css');
window.moment = require('moment');

import Vue from 'vue'

Vue.component('form-ta', require('./component/formTA.vue').default);

let app = new Vue({
	el: '#app',
	data: {
		message: 'Hello developer !'
	}
});