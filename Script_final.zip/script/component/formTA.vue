<template>
    <div class="container">
        <div class="page-header">
            <h1>
                Dynamic Table by date
                <small>
                    <i class="ace-icon fa fa-angle-double-right"></i>
                    form travel & report expense
                </small>
            </h1>
        </div><!-- /.page-header -->
        <div class="row">
            <div class="col-sm-12" style="padding-top: 30px">
            </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="basic-addon1">
                        <i class="fa fa-calendar bigger-110"></i>
                    </span>
                </div>
                <input class="form-control" type="text" name="date-range-picker" id="periodeTA"
                       title="Periode TA"/>
            </div>


            <div class="table-responsive">
                <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                    <thead>
                    <th style="width: 50px">Aksi</th>
                    <th style="width: 300px">Deskripsi</th>
                    <th v-for="i in lamaTA">
                        <span class="rata-kanan"> Hari Ke-{{ i }} </span>
                    </th>
                    <th>
                        <span class="rata-kanan">Total</span>
                    </th>
                    </thead>
                    <tbody>
                    <tr>
                        <td>
                            <div class="action-buttons">
                                <a class="green" title="edit" style="cursor: pointer;"
                                   href="javascript:void(0)" v-if="!isEditAkomodasi" @click="isEditAkomodasi = true">
                                    <i class="ace-icon fa fa-pencil bigger-130"></i>
                                </a>
                                <a class="green" title="simpan" style="cursor: pointer;"
                                   href="javascript:void(0)" v-else @click="saveField('akomodasi')">
                                    <i class="ace-icon fa fa-floppy-o bigger-120 blue"></i>
                                </a>
                            </div>
                        </td>
                        <td>Akomodasi (SPJ)</td>
                        <td v-for="i in lamaTA">
                            <div v-if="isEditAkomodasi">
                                <label>
                                    <input type="number" v-model="akomodasi.hari_ke[i]">
                                </label>
                            </div>
                            <div v-else>
                                <span class="rata-kanan">{{ akomodasi.hari_ke[i] }}</span>
                            </div>
                        </td>
                        <td><span class="rata-kanan">{{ totalAkomodasi }}</span></td>
                    </tr>
                    <tr>
                        <td>
                            <div class="action-buttons">
                                <a class="green" title="edit" style="cursor: pointer;"
                                   href="javascript:void(0)" v-if='!isEditFnB' @click="isEditFnB = true">
                                    <i class="ace-icon fa fa-pencil bigger-130"></i>
                                </a>
                                <a class="green" title="simpan" style="cursor: pointer;"
                                   href="javascript:void(0)" v-else @click="saveField('fnb')">
                                    <i class="ace-icon fa fa-floppy-o bigger-120 blue"></i>
                                </a>
                            </div>
                        </td>
                        <td>Food and Baverage (F&B)</td>
                        <td v-for="i in lamaTA">
                            <div v-if="isEditFnB">
                                <label>
                                    <input type="number" v-model="fnb.hari_ke[i]">
                                </label>
                            </div>
                            <div v-else>
                                <span class="rata-kanan">{{ fnb.hari_ke[i] }}</span>
                            </div>
                        </td>
                        <td><span class="rata-kanan">{{ totalFnB }}</span></td>
                    </tr>
                    </tbody>

                </table>
            </div>

            <center>
                <template v-if="isSubmitLoading">
                    <i class="ace-icon fa fa-spinner fa-spin orange bigger-125"></i>
                </template>
                <template v-else>
                    <button class="btn btn-white btn-info btn-bold" @click="saveToDatabase">
                        <i class="ace-icon fa fa-floppy-o bigger-120 blue"></i>
                        Simpan
                    </button>
                </template>
            </center>
        </div>

    </div>
</template>

<script>
    export default{
        data(){
            return{
                lamaTA: 1,

                isEditAkomodasi: false,
                isEditFnB: false,

                akomodasi: {
                    hari_ke: []
                },
                fnb: {
                    hari_ke: []
                },

                totalAkomodasi: 0,
                totalFnB: 0,

                // loading
                isSubmitLoading: false,
            }
        },
        created(){

        },
        mounted(){
            this.setDateRangePicker()
        },
        methods: {
            setDateRangePicker() {
                let dateRangePicker = $('input[name=date-range-picker]');
                dateRangePicker.daterangepicker(
                    {
                        'applyClass': 'btn-sm btn-success',
                        'cancelClass': 'btn-sm btn-default',
                        locale: {
                            applyLabel: 'Apply',
                            cancelLabel: 'Cancel',
                            format: 'YYYY-MM-DD'
                        },
                    });

                dateRangePicker.on('apply.daterangepicker', (ev, picker) => {
                    let a = moment(picker.startDate.format('YYYY-MM-DD'));
                    let b = moment(picker.endDate.format('YYYY-MM-DD'));
                    this.lamaTA = b.diff(a, 'days') + 1;
                    console.log(this.lamaTA)
                });
            },
            saveField(type){
                let biaya_total = 0;

                if (type === 'akomodasi') {
                    this.isEditAkomodasi = false
                    this.akomodasi.hari_ke.map(e => {
                        if(e !== null) biaya_total += parseInt(e)
                    });
                    if (isNaN(biaya_total)) {
                        biaya_total = 0
                    }
                    this.totalAkomodasi = parseInt(biaya_total)
                }else if(type === 'fnb'){
                    this.isEditFnB = false
                    this.fnb.hari_ke.map(e => {
                        if(e !== null) biaya_total += parseInt(e)
                    });
                    if (isNaN(biaya_total)) {
                        biaya_total = 0
                    }
                    this.totalFnB = parseInt(biaya_total)
                }
            },
            saveToDatabase(){
                this.isSubmitLoading = true
                setTimeout(e => {
                    this.isSubmitLoading = false
                }, 1000)
                
            }
        }

    }
</script>

<style>
    body {
        font-size: 16px
    }

    input {
        width: 100%
    }

    .rata-kanan {
        float: right
    }
</style>